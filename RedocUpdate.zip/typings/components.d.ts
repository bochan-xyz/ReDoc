import { AppStore } from '../services/AppStore';

export interface BaseContainerProps {
  store: AppStore;
}
