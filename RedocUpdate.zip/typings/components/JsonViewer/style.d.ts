export declare const jsonStyles: import("styled-components").FlattenInterpolation<import("styled-components").ThemedStyledProps<object, import("../../theme").ResolvedThemeInterface>>;
