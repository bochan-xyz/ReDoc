export declare const RedocWrap: import("styled-components").StyledComponent<"div", import("../../theme").ResolvedThemeInterface, {}, never>;
export declare const ApiContentWrap: import("styled-components").StyledComponent<"div", import("../../theme").ResolvedThemeInterface, {}, never>;
export declare const BackgroundStub: import("styled-components").StyledComponent<"div", import("../../theme").ResolvedThemeInterface, {}, never>;
