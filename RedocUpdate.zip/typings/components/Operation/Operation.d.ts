import * as React from 'react';
import { OperationModel as OperationType } from '../../services/models';
export interface OperationProps {
    operation: OperationType;
}
export declare class Operation extends React.Component<OperationProps> {
    handleKeyDown: (event: React.KeyboardEvent<HTMLHeadingElement>) => void;
    render(): JSX.Element;
}
