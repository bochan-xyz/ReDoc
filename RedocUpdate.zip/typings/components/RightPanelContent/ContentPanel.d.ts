import * as React from 'react';
interface ContentPanelProps {
    content: string;
}
export declare class ContentPanel extends React.Component<ContentPanelProps> {
    render(): JSX.Element;
}
export {};
