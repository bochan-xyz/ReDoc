import * as React from 'react';
import { RedocNormalizedOptions } from '../../../src/services';
import { OperationModel } from '../../../src/services/models';
interface RightPanelContentProps {
    operation: OperationModel;
    options: RedocNormalizedOptions;
}
export declare class OperationPanel extends React.Component<RightPanelContentProps> {
    render(): JSX.Element;
    private shouldShowOtherInfoPanel;
}
export {};
