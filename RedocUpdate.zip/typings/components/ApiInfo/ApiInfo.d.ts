import * as React from 'react';
import { AppStore } from '../../services/AppStore';
export interface ApiInfoProps {
    store: AppStore;
}
export declare class ApiInfo extends React.Component<ApiInfoProps> {
    state: {
        gotoIconColor: string;
        gotoTextColor: string;
    };
    handleHoverState: () => void;
    handleActiveState: () => void;
    handleLeaveState: () => void;
    handleDownloadClick: (e: any) => void;
    render(): JSX.Element;
}
