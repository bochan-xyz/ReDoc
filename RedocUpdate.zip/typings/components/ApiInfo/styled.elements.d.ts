export declare const ApiInfoWrap: import("styled-components").StyledComponent<"div", import("../../theme").ResolvedThemeInterface, {
    compact?: boolean | undefined;
}, never>;
export declare const ApiHeader: import("styled-components").StyledComponent<"h1", import("../../theme").ResolvedThemeInterface, {}, never>;
export declare const AdditionalDocLink: import("styled-components").StyledComponent<"a", import("../../theme").ResolvedThemeInterface, {}, never>;
export declare const DownloadButton: import("styled-components").StyledComponent<"a", import("../../theme").ResolvedThemeInterface, {}, never>;
export declare const InfoSpan: import("styled-components").StyledComponent<"span", import("../../theme").ResolvedThemeInterface, {}, never>;
export declare const InfoSpanBoxWrap: import("styled-components").StyledComponent<"div", import("../../theme").ResolvedThemeInterface, {}, never>;
export declare const InfoSpanBox: import("styled-components").StyledComponent<"div", import("../../theme").ResolvedThemeInterface, {}, never>;
