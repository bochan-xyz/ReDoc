import * as React from 'react';
import { SchemaProps } from './Schema';
export declare class ArraySchema extends React.PureComponent<SchemaProps> {
    render(): JSX.Element;
}
