/// <reference types="react" />
export declare const AnimatedChevronButton: ({ open }: {
    open: boolean;
}) => JSX.Element;
