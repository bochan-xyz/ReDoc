import * as React from 'react';
import { ResponseModel } from '../../services/models';
export declare class ResponseDetails extends React.PureComponent<{
    response: ResponseModel;
}> {
    render(): JSX.Element;
    private renderDropdown;
}
