import * as React from 'react';
export interface ResponseTitleProps {
    code: string;
    title: string;
    type: string;
    empty?: boolean;
    opened?: boolean;
    className?: string;
    onClick?: () => void;
    parent: any;
}
export declare class ResponseTitle extends React.PureComponent<ResponseTitleProps> {
    handleKeyDown: (event: React.KeyboardEvent<HTMLDivElement>) => void;
    render(): JSX.Element;
}
