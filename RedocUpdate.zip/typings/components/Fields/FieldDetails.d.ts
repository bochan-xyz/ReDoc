import * as React from 'react';
import { FieldProps } from './Field';
export declare class FieldDetails extends React.PureComponent<FieldProps> {
    static contextType: React.Context<import("../..").RedocNormalizedOptions>;
    render(): JSX.Element;
}
