import * as React from 'react';
export interface ExtensionsProps {
    extensions: {
        [k: string]: any;
    };
}
export declare class Extensions extends React.PureComponent<ExtensionsProps> {
    render(): JSX.Element;
}
