import * as React from 'react';
export interface ConstraintsViewProps {
    constraints: string[];
}
export declare class ConstraintsView extends React.PureComponent<ConstraintsViewProps> {
    render(): JSX.Element | null;
}
