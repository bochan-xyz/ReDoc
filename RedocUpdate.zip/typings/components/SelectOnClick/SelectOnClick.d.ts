import * as React from 'react';
export interface SelectOnClickProps {
    parentForToggle?: any;
}
export declare class SelectOnClick extends React.PureComponent<SelectOnClickProps> {
    private child;
    handleKeyDown: (event: React.KeyboardEvent<HTMLDivElement>) => void;
    handleClick: () => void;
    render(): JSX.Element;
}
