export declare const ApiBackToText: import("styled-components").StyledComponent<"a", import("../../theme").ResolvedThemeInterface, {}, never>;
