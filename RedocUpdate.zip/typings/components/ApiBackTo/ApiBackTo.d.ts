import * as React from 'react';
export declare class ApiBackTo extends React.Component<{
    groupId: string | undefined;
    groupName: string | undefined;
}> {
    state: {
        backTextColor: string;
    };
    specialEncode(url: string): string;
    handleHoverState: () => void;
    handleLeaveState: () => void;
    render(): JSX.Element;
}
