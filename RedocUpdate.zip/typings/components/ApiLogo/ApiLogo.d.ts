import * as React from 'react';
import { OpenAPIInfo } from '../../types';
export declare class ApiLogo extends React.Component<{
    info: OpenAPIInfo;
}> {
    render(): JSX.Element | null;
}
