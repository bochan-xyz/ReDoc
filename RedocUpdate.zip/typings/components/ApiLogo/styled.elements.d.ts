/// <reference types="react" />
export declare const LogoImgEl: import("styled-components").StyledComponent<"img", import("../../theme").ResolvedThemeInterface, {}, never>;
export declare const LogoWrap: import("styled-components").StyledComponent<"div", import("../../theme").ResolvedThemeInterface, {}, never>;
export declare const LinkWrap: (url: any) => (Component: any) => JSX.Element;
