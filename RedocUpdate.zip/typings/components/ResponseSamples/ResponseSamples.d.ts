import * as React from 'react';
import { OperationModel } from '../../services/models';
export interface ResponseSamplesProps {
    operation: OperationModel;
}
export declare class ResponseSamples extends React.Component<ResponseSamplesProps> {
    operation: OperationModel;
    render(): JSX.Element | null;
}
