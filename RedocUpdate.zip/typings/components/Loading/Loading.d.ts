import * as React from 'react';
export interface LoadingProps {
    color: string;
}
export declare class Loading extends React.PureComponent<LoadingProps> {
    render(): JSX.Element;
}
