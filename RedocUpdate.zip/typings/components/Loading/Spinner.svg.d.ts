/// <reference types="react" />
export declare const Spinner: import("styled-components").StyledComponent<(props: {
    className?: string | undefined;
    color: string;
}) => JSX.Element, import("../../theme").ResolvedThemeInterface, {}, never>;
