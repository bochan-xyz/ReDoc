import { ExampleModel } from '../../services/models/Example';
export declare function useExternalExample(example: ExampleModel, mimeType: string): any;
