/// <reference types="react" />
export interface ExampleValueProps {
    value: any;
    mimeType: string;
}
export declare function ExampleValue({ value, mimeType }: ExampleValueProps): JSX.Element;
