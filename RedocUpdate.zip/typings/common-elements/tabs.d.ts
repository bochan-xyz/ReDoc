import { Tabs as ReactTabs } from 'react-tabs';
export { Tab, TabList, TabPanel } from 'react-tabs';
export declare const Tabs: import("styled-components").StyledComponent<typeof ReactTabs, import("../theme").ResolvedThemeInterface, {}, never>;
export declare const JunkErrorTabs: import("styled-components").StyledComponent<typeof ReactTabs, import("../theme").ResolvedThemeInterface, {}, never>;
export declare const ResponseTabs: import("styled-components").StyledComponent<typeof ReactTabs, import("../theme").ResolvedThemeInterface, {}, never>;
export declare const RequestTabs: import("styled-components").StyledComponent<typeof ReactTabs, import("../theme").ResolvedThemeInterface, {}, never>;
export declare const SmallTabs: import("styled-components").StyledComponent<typeof ReactTabs, import("../theme").ResolvedThemeInterface, {}, never>;
