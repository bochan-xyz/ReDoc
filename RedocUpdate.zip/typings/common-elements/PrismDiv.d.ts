export declare const PrismDiv: import("styled-components").StyledComponent<"div", import("../theme").ResolvedThemeInterface, {}, never>;
