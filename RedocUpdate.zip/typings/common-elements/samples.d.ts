export declare const SampleControls: import("styled-components").StyledComponent<"div", import("../theme").ResolvedThemeInterface, {}, never>;
export declare const SampleControlsWrap: import("styled-components").StyledComponent<"div", import("../theme").ResolvedThemeInterface, {}, never>;
export declare const StyledPre: import("styled-components").StyledComponent<"pre", import("../theme").ResolvedThemeInterface, {}, never>;
