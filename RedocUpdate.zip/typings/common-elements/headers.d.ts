export declare const headerCommonMixin: (level: any) => import("styled-components").FlattenInterpolation<import("styled-components").ThemedStyledProps<object, import("../theme").ResolvedThemeInterface>>;
export declare const H1: import("styled-components").StyledComponent<"h1", import("../theme").ResolvedThemeInterface, {}, never>;
export declare const H2: import("styled-components").StyledComponent<"h2", import("../theme").ResolvedThemeInterface, {}, never>;
export declare const H3: import("styled-components").StyledComponent<"h2", import("../theme").ResolvedThemeInterface, {}, never>;
export declare const RightPanelHeader: import("styled-components").StyledComponent<"div", import("../theme").ResolvedThemeInterface, {}, never>;
export declare const UnderlinedHeader: import("styled-components").StyledComponent<"h5", import("../theme").ResolvedThemeInterface, {}, never>;
