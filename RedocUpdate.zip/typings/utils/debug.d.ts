export declare function debugTime(label: string): void;
export declare function debugTimeEnd(label: string): void;
