export declare function jsonToHTML(json: any, maxExpandLevel: any): string;
