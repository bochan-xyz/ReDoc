export declare function Throttle(delay: number): (_: any, _2: any, desc: PropertyDescriptor) => void;
