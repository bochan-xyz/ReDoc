export declare function memoize<T>(target: any, name: string, descriptor: TypedPropertyDescriptor<T>): TypedPropertyDescriptor<T>;
