export declare class Constants {
    static readonly OTX_EXTENSION_KEY = "x-opentext-other";
}
